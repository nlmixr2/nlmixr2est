foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nrx_expr_3~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_3);\nd/dt(depot)=-rx_expr_5*depot;\nrx_expr_0~phiU(ETA[2]);\nrx_expr_1~exp(-THETA[3]);\nrx_expr_4~THETA[2]+THETA[3];\nrx_expr_6~rx_expr_5*depot;\nrx_expr_7~rx_expr_4-THETA[4];\nrx_expr_8~exp(rx_expr_7);\nrx_expr_9~rx_expr_8*center;\nd/dt(center)=rx_expr_6-rx_expr_9*gammapInv(rx_expr_1,rx_expr_0);\nrx_expr_11~rx_expr_5*rx__sens_depot_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_5*depot-rx_expr_11;\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_6+rx_expr_11-rx_expr_8*rx__sens_center_BY_ETA_1___*gammapInv(rx_expr_1,rx_expr_0);\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_5*rx__sens_depot_BY_ETA_2___;\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_5*rx__sens_depot_BY_ETA_2___-rx_expr_8*rx__sens_center_BY_ETA_2___*gammapInv(rx_expr_1,rx_expr_0)-rx_expr_9/gammapDer(rx_expr_1,gammapInv(rx_expr_1,rx_expr_0))*0.398942280401433*exp(-0.5*(ETA[2])*(ETA[2]));\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_2~exp(-THETA[4]);\nrx_pred_=rx_expr_2*center;\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_2*rx__sens_center_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_2*rx__sens_center_BY_ETA_2___;\nrx_r_=Rx_pow_di(THETA[5],2);\nrx__sens_rx_r__BY_ETA_1___=0;\nrx__sens_rx_r__BY_ETA_2___=0;\ncmt(cp);\ndvid(3);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_expr_3~ETA[1]+THETA[1]\nrx_expr_5~exp(rx_expr_3)\nd/dt(depot)=-rx_expr_5*depot\nrx_expr_0~phiU(ETA[2])\nrx_expr_1~exp(-THETA[3])\nrx_expr_4~THETA[2]+THETA[3]\nrx_expr_6~rx_expr_5*depot\nrx_expr_7~rx_expr_4-THETA[4]\nrx_expr_8~exp(rx_expr_7)\nrx_expr_9~rx_expr_8*center\nd/dt(center)=rx_expr_6-rx_expr_9*gammapInv(rx_expr_1, rx_expr_0)\nrx_expr_11~rx_expr_5*rx__sens_depot_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_5*depot-rx_expr_11\nd/dt(rx__sens_center_BY_ETA_1___)=rx_expr_6+rx_expr_11-rx_expr_8*rx__sens_center_BY_ETA_1___*gammapInv(rx_expr_1, rx_expr_0)\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_5*rx__sens_depot_BY_ETA_2___\nd/dt(rx__sens_center_BY_ETA_2___)=rx_expr_5*rx__sens_depot_BY_ETA_2___-rx_expr_8*rx__sens_center_BY_ETA_2___*gammapInv(rx_expr_1, rx_expr_0)-rx_expr_9/gammapDer(rx_expr_1, gammapInv(rx_expr_1, rx_expr_0))*0.398942280401433*exp(-0.5*(ETA[2])*(ETA[2]))\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_2~exp(-THETA[4])\nrx_pred_=rx_expr_2*center\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_2*rx__sens_center_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_2*rx__sens_center_BY_ETA_2___\nrx_r_=Rx_pow_di(THETA[5], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__sens_rx_r__BY_ETA_2___=0\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nrx_expr_3~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_3);\nd/dt(depot)=-rx_expr_5*depot;\nrx_expr_0~phiU(ETA[2]);\nrx_expr_1~exp(-THETA[3]);\nrx_expr_4~THETA[2]+THETA[3];\nd/dt(center)=rx_expr_5*depot-exp(rx_expr_4-THETA[4])*center*gammapInv(rx_expr_1,rx_expr_0);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_2~exp(-THETA[4]);\nrx_expr_6~rx_expr_2*center;\nrx_pred_=rx_expr_6;\nrx_r_=Rx_pow_di(THETA[5],2);\ntka=THETA[1];\nlclm=THETA[2];\nlclrv=THETA[3];\ntv=THETA[4];\nadd.sd=THETA[5];\neta.ka=ETA[1];\nrxz.eta.cl=ETA[2];\nrxN.eta.cl=ETA[2];\nrx_expr_7~exp(rx_expr_4);\neta.cl=rx_expr_7*gammapInv(rx_expr_1,rx_expr_0);\nka=rx_expr_5;\ncl=rx_expr_7*gammapInv(rx_expr_1,rx_expr_0);\nv=exp(THETA[4]);\ncp=rx_expr_6;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],ETA[1],ETA[2]);\ncmt(depot);\ncmt(center);\nrx_expr_0~ETA[1]+THETA[1];\nrx_expr_1~exp(rx_expr_0);\nd/dt(depot)=-rx_expr_1*depot;\nd/dt(center)=rx_expr_1*depot-exp(THETA[2]+THETA[3]-THETA[4])*center*gammapInv(exp(-THETA[3]),phiU(ETA[2]));\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=exp(-THETA[4])*center;\nrx_r_=Rx_pow_di(THETA[5],2);\ncmt(cp);\ndvid(3);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

