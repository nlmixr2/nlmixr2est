ui <- function () 
{
    ini({
        tka <- 0.406246334638212
        lclm <- 1.08470980399563
        lclrv <- -2.1446848352056
        tv <- 3.4296080308114
        add.sd <- c(0, 0.781336493817979)
        eta.ka ~ 0.330568597742056
        rxz.eta.cl ~ fix(1)
    })
    model({
        rxN.eta.cl <- rxz.eta.cl
        eta.cl <- gammapInv((1/exp(lclrv)), phiU(rxN.eta.cl))/((1/(exp(lclrv) * 
            exp(lclm))))
        ka <- exp(tka + eta.ka)
        cl <- eta.cl
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "gammaCl", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

