ui <- function () 
{
    ini({
        tka <- 0.398125042748639
        lclm <- 1.08392128601602
        lclrv <- -2.10493164083935
        tv <- 3.42963396573857
        add.sd <- c(0, 0.782703926457986)
        eta.ka ~ 0.326530428036696
        rxz.eta.cl ~ fix(1)
    })
    model({
        rxN.eta.cl <- rxz.eta.cl
        eta.cl <- gammapInv((1/exp(lclrv)), phiU(rxN.eta.cl))/((1/(exp(lclrv) * 
            exp(lclm))))
        ka <- exp(tka + eta.ka)
        cl <- eta.cl
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "gammaCl", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

